function val = integrand4(x)
val =0.5.*(x>pi/4)+0.1.*(x<pi/4)+0.3.*(x==pi/4);